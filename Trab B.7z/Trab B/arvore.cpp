#include <vector>
#include <fstream>
#include <string>


using namespace std;

class Arvore
{
public:

    Pessoa* getPessoa(string nome){
        vector<Pessoa*>::iterator it;
        for(it = listaPessoas.begin(); it!=listaPessoas.end(); it++){
            if((*it)->getNome()==nome)
                return *it;
        }
        return NULL;
    }

    Pessoa* setPessoa(string nome){
        vector<Pessoa*>::iterator it;
        for(it = listaPessoas.begin(); it!=listaPessoas.end(); it++){

        }
        return NULL;
    }

    void salvarDados(string path)
    {
        fstream fs;
        vector<Pessoa*>::iterator it;
        fs.open(path.c_str(), fstream::out|fstream::trunc);
        if(fs.is_open())
        {
            ss<<"Nome\tSexo\tIdade\tOlhos\tPai\tMae"<<endl;
            for(it = listaPessoas.begin(); it!=listaPessoas.end(); it++)
                fs << (*it)->serialize();

            fs.close();
        }
        else
        {
            cout << "ERRO" <<endl;
        }
    }

    Pessoa carregarDados(string path)
    {
        Pessoa* filho;
        fstream fs;
        string linha;
        vector<Pessoa*>::iterator it;
        fs.open(path.c_str(), fstream::in);
        if(fs.is_open())
        {
            getline(fs,linha);
            while(!fs.eof())
            {
                getline(fs, linha);
                listaPessoas.push_back(new Pessoa(linha));
            }
            fs.close();
            fs.open(path.c_str(), fstream::in);
            if(fs.is_open())
            {
                string tempfil;
                string temppai;
                string tempmae;
                getline(fs,linha);
                while(!fs.eof()){
                    getline(fs, tempfil, '\t');
                    getline(fs,linha,'\t');
                    getline(fs,linha,'\t');
                    getline(fs,linha,'\t');
                    getline(fs, temppai, '\t');
                    getline(fs, tempmae);
                    filho=this->getPessoa(tempfil);
                    filho->setpai(Arvore::getPessoa(temppai));
                    filho->setmae(Arvore::getPessoa(tempmae));
                }
            }
            else
            {
                cout << "ERRO" <<endl;
            }
        }

        void inserirPessoa(Pessoa* pessoa)
        {
            listaPessoas.push_back(pessoa);
        }

        void removePessoa(Pessoa* pessoa)
        {

        }

protected:

private:
        vector <Pessoa*> listaPessoas;
    };
